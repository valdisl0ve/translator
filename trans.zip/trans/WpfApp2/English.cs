﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WpfApp2
{
    class English : Language
    {
        public static Dictionary<string, string> wordsEN = new Dictionary<string, string>();


        public string to_translate { get; set; }
        public string result { get; set; }
        
        public static string new_word {get; set; }
        
        
       

        public override void Translate()
        {
            EngishCheck();
            string value;
            if (wordsEN.TryGetValue(to_translate, out value))
            {
                result = value;
            }

            if (!wordsEN.ContainsKey(to_translate))
            {
                result = "no translate";
            }

         


        }


            public static void EngishCheck()
            {
                wordsEN.Clear();
                StreamReader sr = new StreamReader(@"C:\Users\VLAD\source\repos\trans\WpfApp2\English.txt");
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    string[] word = line.Split('-');
                    wordsEN.Add(word[0], word[1]);
                    
                }
                sr.Close();
            }


            public void AddNewWord()
            {
                StreamWriter sw = new StreamWriter(@"C:\Users\VLAD\source\repos\trans\WpfApp2\English.txt",  true);
                sw.WriteLine( to_translate + "-" + new_word );
                sw.Close();
            }
            
            
            
            
            
            
            
        
    }
}
